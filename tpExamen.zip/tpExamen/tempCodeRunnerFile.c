for (i = 0; i < pos - 1; i++)
    // {
    //     for (j = i; i < pos; i++)
    //     {
    //         if (tab[j] > tab[j + 1])
    //         {
    //             tmp = tab[j];
    //             tab[j] = tab[j + 1];
    //             tab[j + 1] = tmp;
    //         }
    //     }
    // }
    // printf("Voici votre tableau \n");
    // for (i = 0; i < n; i++)
    // {
    //     printf("%d--%d \n", i, tab[i]);
    // }
    // // Faire le tri des elements impaires

    // for (i = pos; i < n - 1; i++)
    // {
    //     for (j = i; i < n; i++)
    //     {
    //         if (tab[j] < tab[j + 1])
    //         {
    //             tmp = tab[j];
    //             tab[j] = tab[j + 1];
    //             tab[j + 1] = tmp;
    //         }
    //     }
    // }
    // printf("Voici votre tableau \n");
    // for (i = 0; i < n; i++)
    // {
    //     printf("%d--%d \n", i, tab[i]);
    // }